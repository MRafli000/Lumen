<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Payment;

class PaymentController extends Controller
{
    public function store(Request $request)
    {
        $this->validate($request, [       
            'id_peminjam' => 'required|integer',
            'tanggal_pembayaran' => 'required|date',
            'jumlah_pembayaran' => 'required|integer|min:0',
        ]);
        $payment = Payment::create($request->all());
        return response()->json([
            'message' => 'Data peminjaman berhasil ditambahkan',
            'data' => $payment
        ], 201);
    }

    public function index()
    {
    $payment = Payment::all();
    return response()->json([
        'data' => $payment
    ]);
    }

    public function show($id)
    {
    $payment = Payment::findOrFail($id);
    return response()->json([
        'data' => $payment
    ]);
    }

    public function update(Request $request, $id)
    {
    $request->validate([
        'tanggal_pembayaran' => 'required|date'
    ]);
    $payment = Payment::findOrFail($id);
    $payment->status = $request->status;
    $payment->save();
    return response()->json([
        'message' => 'Data pembayaran berhasil diperbarui',
        'data' => $payment
    ]);
    }

    public function destroy($id)
    {
    $payment = Payment::findOrFail($id);
    $payment->delete();
    return response()->json([
        'message' => 'Data pembayaran berhasil dihapus'
    ]);
    }
}
