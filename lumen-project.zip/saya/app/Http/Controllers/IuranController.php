<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Iuran;

class IuranController extends Controller
{

    // OK
    public function index()
    {
    $iuran = Iuran::all();
    return response()->json([
        'data' => $iuran
    ]);
    }

    
    public function store(Request $request)
    {
        $this->validate($request, [   
            'id_warga' => 'required|integer',
            'bulan' => 'required|date',
            //'bulan' => 'required|integer',
            'jumlah_iuran' => 'required|integer|min:0',
            'status' => 'required|in:pending,approved,rejected'
        ]);
        $iuran = Iuran::create($request->all());
        return response()->json([
            'message' => 'Data iuran berhasil ditambahkan',
            'data' => $Iuran
        ], 201);
    }


    // OK
    public function show($id)
    {
    $iuran = Iuran::findOrFail($id);
    return response()->json([
        'data' => $iuran
    ]);
    }


    // OK
    public function update(Request $request, $id)
    {
    $request->validate([
        'status' => 'required|in:pending,approved,rejected'
    ]);
    $Iuran = Iuran::findOrFail($id);
    $Iuran->status = $request->status;
    $Iuran->save();
    return response()->json([
        'message' => 'Data iuran berhasil diperbarui',
        'data' => $Iuran
    ]);
    }


    // OK
    public function destroy($id)
    {
    $iuran = Iuran::findOrFail($id);
    $iuran->delete();
    return response()->json([
        'message' => 'Data iuran berhasil dihapus'
    ]);
    }
}
