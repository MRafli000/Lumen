<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;

class CustomerController extends Controller
{
    public function store(Request $request)
    {
        $this->validate($request, [
            'nama' => 'required|string',
            'alamat' => 'required|string',
            'telepon' => 'required|string',
        ]);
        $customer = Customer::create($request->all());
        return response()->json([
            'message' => 'Data customer berhasil ditambahkan',
            'data' => $customer
        ], 201);
    }

    public function index()
    {
    $customer = Customer::all();
    return response()->json([
        'data' => $customer
    ]);
    }

    public function show($id)
    {
    $customer = Customer::findOrFail($id);
    return response()->json([
        'data' => $customer
    ]);
    }

    public function update(Request $request, $id)
    {
    $request->validate([
        'alamat' => 'required|date'
    ]);
    $customer = Customer::findOrFail($id);
    $customer->status = $request->status;
    $customer->save();
    return response()->json([
        'message' => 'Data customer berhasil diperbarui',
        'data' => $customer
    ]);
    }

    public function destroy($id)
    {
    $customer = customer::findOrFail($id);
    $customer->delete();
    return response()->json([
        'message' => 'Data customer berhasil dihapus'
    ]);
    }
}
