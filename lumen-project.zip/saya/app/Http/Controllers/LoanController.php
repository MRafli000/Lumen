<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Loan;

class LoanController extends Controller
{
    public function index()
    {
    $loan = Loan::all();
    return response()->json([
        'data' => $loan
    ]);
    }

    public function store(Request $request)
    {
        $this->validate($request, [   
            'id_anggota' => 'required|integer',
            'tanggal_pinjam' => 'required|date',
            'jumlah_pinjam' => 'required|integer|min:0',
            'status' => 'required|in:pending,approved,rejected'
        ]);
        $loan = Loan::create($request->all());
        return response()->json([
            'message' => 'Data peminjaman berhasil ditambahkan',
            'data' => $loan
        ], 201);
    }

    public function show($id)
    {
    $loan = Loan::findOrFail($id);
    return response()->json([
        'data' => $loan
    ]);
    }

    public function update(Request $request, $id)
    {
    $request->validate([
        'status' => 'required|in:pending,approved,rejected,selesai'
    ]);
    $loan = Loan::findOrFail($id);
    $loan->status = $request->status;
    $loan->save();
    return response()->json([
        'message' => 'Data peminjaman berhasil diperbarui',
        'data' => $loan
    ]);
    }

    public function destroy($id)
    {
    $loan = Loan::findOrFail($id);
    $loan->delete();
    return response()->json([
        'message' => 'Data peminjaman berhasil dihapus'
    ]);
    }
}
