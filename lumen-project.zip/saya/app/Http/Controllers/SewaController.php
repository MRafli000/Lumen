<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Sewa;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class SewaController extends Controller
{
    protected $blacklist = [
        2 => 'Pembayaran tertunggak'
    ];

    public function store(Request $request)
    {
        $this->validate($request, [
            'penyewa_id' => 'required|integer',
            'mobil_id' => 'required|integer',
            'tanggal_sewa' => 'required|date',
            'status' => 'required|string',
        ]);

        if (isset($this->blacklist[$request->penyewa_id])) {
            return response()->json([
                'message' => 'Penyewa ini berada dalam daftar hitam dan tidak diizinkan untuk menyewa.',
                'alasan' => $this->blacklist[$request->penyewa_id]
            ], 403);
        }

        $sewa = Sewa::create($request->all());
        $sewa->tanggal_kembali = null;  // Ensure this key exists
        $sewa->total_harga = null;      // Ensure this key exists
        $sewa->denda = 0;               // Ensure this key exists
        return response()->json([
            'message' => 'Data sewa berhasil ditambahkan',
            'data' => $sewa
        ], 201);
    }

    // ... kode lainnya tetap sama

    public function index()
    {
        $sewa = Sewa::all();
        return response()->json([
            'data' => $sewa
        ]);
    }

    public function show($id)
    {
        $sewa = Sewa::findOrFail($id);
        return response()->json([
            'data' => $sewa
        ]);
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'tanggal_kembali' => 'sometimes|date',
            'total_harga' => 'sometimes|integer',
            'status' => 'sometimes|string',
        ]);

        $sewa = Sewa::findOrFail($id);
        $sewa->update($request->all());

        // Contoh penghitungan denda
        $denda = 0;
        if ($request->status === 'completed' && $request->tanggal_kembali > $sewa->tanggal_sewa) {
            $denda = 50000; // Contoh perhitungan denda
            $sewa->denda = $denda;
        }

        return response()->json([
            'message' => 'Data sewa berhasil diperbarui',
            'data' => $sewa
        ]);
    }

    public function destroy($id)
    {
        $sewa = Sewa::findOrFail($id);
        $sewa->delete();
        return response()->json([
            'message' => 'Data sewa berhasil dihapus'
        ]);
    }
}
