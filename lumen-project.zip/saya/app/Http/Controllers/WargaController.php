<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Warga;

class WargaController extends Controller
{

    // OK
    public function index()
    {
    $warga = Warga::all();
    return response()->json([
        'data' => $warga
    ]);
    }

    // OK
    public function store(Request $request)
    {
        $this->validate($request, [   
            'nama' => 'required|string',
            'alamat' => 'required|string',
        ]);
        $warga = Warga::create($request->all());
        return response()->json([
            'message' => 'Data sudah ditambahkan',
            'data' => $warga
        ], 201);
    }


    // OK
    public function show($id)
    {
    $warga = Warga::findOrFail($id);
    return response()->json([
        'data' => $warga
    ]);
    }


    // OK
    public function update(Request $request, $id)
    {
    $request->validate([
        'alamat' => 'required|string'
    ]);
    $warga = Warga::findOrFail($id);
    $warga->status = $request->status;
    $warga->save();
    return response()->json([
        'message' => 'Data berhasil diperbarui',
        'data' => $warga
    ]);
    }


    // OK
    public function destroy($id)
    {
    $warga = Warga::findOrFail($id);
    $warga->delete();
    return response()->json([
        'message' => 'Data berhasil dihapus'
    ]);
    }
}
