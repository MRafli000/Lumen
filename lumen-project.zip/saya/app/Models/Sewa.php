<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sewa extends Model
{
    protected $table = 'sewa';
    
    protected $fillable = [
        'penyewa_id',
        'mobil_id',
        'tanggal_sewa',
        'tanggal_kembali',
        'total_harga',
        'status',
        'denda'
    ];

}
