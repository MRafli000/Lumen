<?php


/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->get('/books', 'BooksController@index');
$router->get('/books/{id:[\d]+}', [
    'as' => 'books.show',
    'uses' => 'BooksController@show'
]);

$router->post('/books', 'BooksController@store');
$router->put('/books/{id:[\d]+}', 'BooksController@update');
$router->delete('/books/{id:[\d]+}', 'BooksController@destroy');




$router->get('/payments', 'PaymentController@index');
$router->get('/payments/{id:[\d]+}', [
    'as' => 'payments.show',
    'uses' => 'PaymentController@show'
]);

$router->post('/payments', 'PaymentController@store');
$router->put('/payments/{id:[\d]+}', 'PaymentController@update');
$router->delete('/payments/{id:[\d]+}', 'PaymentController@destroy');

// Routes for handling loans

$router->get('/loans', 'LoanController@index');
$router->get('/loans/{id:[\d]+}', [
    'as' => 'loans.show',
    'uses' => 'LoanController@show'
]);

$router->post('/loans', 'LoanController@store');
$router->put('/loans/{id:[\d]+}', 'LoanController@update');
$router->delete('/loans/{id:[\d]+}', 'LoanController@destroy');


//Route::get('/loans', [LoanController::class, 'index']);
//Route::post('/loans', [LoanController::class, 'store']);
//Route::get('/loans/{id}', [LoanController::class, 'show']);
//Route::put('/loans/{id}', [LoanController::class, 'update']);
//Route::delete('/loans/{id}', [LoanController::class, 'destroy']);

$router->get('/customers', 'CustomerController@index');
$router->get('/customers/{id:[\d]+}', [
    'as' => 'customers.show',
    'uses' => 'CustomerController@show'
]);

$router->post('/customers', 'CustomerController@store');
$router->put('/customers/{id:[\d]+}', 'CustomerController@update');
$router->delete('/customers/{id:[\d]+}', 'CustomerController@destroy');

//
//$router->get('/authors', 'AuthorsController@index');
//$router->get('/authors/{id:[\d]+}', [
    //'as' => 'authors.show',
    //'uses' => 'AuthorsController@show'
//]);

//$router->post('/authors', 'AuthorsController@store');
//$router->put('/authors/{id:[\d]+}', 'AuthorsController@update');
//$router->delete('/authors/{id:[\d]+}', 'AuthorsController@destroy');
//

//$router->group([
    //'prefix' => '/authors',
    //'namespace' => 'App\Http\Controllers' 
//],  function  (\Laravel\Lumen\Application $router) { 
    //$router->get('/', 'AuthorsController@index'); 
    //$router->post('/', 'AuthorsController@store');

    //$router->get('/{id:[\d]+}', [
        //'as' => 'authors.show', 
        //'uses' => 'AuthorsController@show'
    //]);

    //$router->put('/{id:[\d]+}', 'AuthorsController@update'); 
    //$router->delete('/{id:[\d]+}', 'AuthorsController@destroy'); 
//});

Route::group(['prefix' => 'authors'],function() {
    Route::get('/', 'AuthorsController@index');
    Route::get('/{id:[\d]+}', [
        'as' => 'authors.show',
        'uses' => 'AuthorsController@show'
    ]);
    Route::post('/', 'AuthorsController@store');
    Route::put('/{id:[\d]+}', 'AuthorsController@update');
    Route::delete('/{id:[\d]+}', 'AuthorsController@destroy');
});


//  tabel Warga //
$router->get('/warga', 'WargaController@index');
$router->get('/warga/{id:[\d]+}', [
    'as' => 'warga.show',
    'uses' => 'WargaController@show'
]);

$router->post('/warga', 'WargaController@store');
$router->put('/warga/{id:[\d]+}', 'WargaController@update');
$router->delete('/warga/{id:[\d]+}', 'WargaController@destroy');

// Iuran //
$router->get('/iuran', 'IuranController@index');
$router->get('/iuran/{id:[\d]+}', [
    'as' => 'iuran.show',
    'uses' => 'IuranController@show'
]);

$router->post('/iuran', 'IuranController@store');
$router->put('/iuran/{id:[\d]+}', 'IuranController@update');
$router->delete('/iuran/{id:[\d]+}', 'IuranController@destroy');


///////////////////////////////

$router->get('/sewa', 'SewaController@index');
$router->get('/sewa/{id:[\d]+}', [
    'as' => 'sewa.show',
    'uses' => 'SewaController@show'
]);

$router->post('/sewa', 'SewaController@store');
$router->put('/sewa/{id:[\d]+}', 'SewaController@update');
$router->delete('/sewa/{id:[\d]+}', 'SewaController@destroy');