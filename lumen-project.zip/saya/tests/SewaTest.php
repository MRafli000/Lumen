<?php

namespace Tests;

use Laravel\Lumen\Testing\DatabaseMigrations;
use Laravel\Lumen\Testing\DatabaseTransactions;
use App\Models\Sewa;


class SewaTest extends TestCase
{
    use DatabaseMigrations;

    protected $blacklist = [
        2 => 'Pembayaran tertunggak'
    ];

    /** @test */
    public function test_create_sewa_blacklisted_penyewa()
    {
        $requestData = [
            'penyewa_id' => 2,
            'mobil_id' => 1,
            'tanggal_sewa' => '2024-06-12',
            'status' => 'ongoing'
        ];

        $this->json('POST', '/sewa', $requestData)
             ->seeStatusCode(403)
             ->seeJson([
                'message' => 'Penyewa ini berada dalam daftar hitam dan tidak diizinkan untuk menyewa.',
                'alasan' => 'Pembayaran tertunggak'
             ]);
    }

    /** @test */
    public function test_create_sewa_non_blacklisted_penyewa()
    {
        $requestData = [
            'penyewa_id' => 1,
            'mobil_id' => 1,
            'tanggal_sewa' => '2024-06-12',
            'status' => 'ongoing'
        ];

        $this->json('POST', '/sewa', $requestData)
             ->seeStatusCode(201)
             ->seeJsonStructure([
                'message',
                'data' => [
                    'id',
                    'penyewa_id',
                    'mobil_id',
                    'tanggal_sewa',
                    'tanggal_kembali',
                    'total_harga',
                    'status',
                    'denda',
                    'created_at',
                    'updated_at'
                ]
             ]);
    }
}
