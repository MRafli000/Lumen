<?php

namespace Database\Seeders;

use Carbon\Carbon;
use App\Models\Book;
use App\Models\Author;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Database\Factories\ModelFactory;
use Database\Factories\AuthorFactory;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class BooksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        AuthorFactory::new()->count(10)->create()->each(function (Author $author) {
            $booksCount = rand(1, 5);

            while ($booksCount > 0) {
                $author->books()->save(ModelFactory::new()->make());
                $booksCount--;
            }
        });

    }
}
